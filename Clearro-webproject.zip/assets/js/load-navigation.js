// Function to load navigation
function loadNavigation() {
  // Create a new XMLHttpRequest object
  const xhr = new XMLHttpRequest();
  
  // Configure it to load the navigation.html file
  xhr.open('GET', 'includes/navigation.html', true);
  
  // Set up the callback function for when the request completes
  xhr.onload = function() {
    if (this.status >= 200 && this.status < 300) {
      // Success! Insert the navigation HTML at the beginning of the body
      document.body.insertAdjacentHTML('afterbegin', this.responseText);
      
      // Update the active state based on current page
      updateActiveNavItem();
    } else {
      console.error('Failed to load navigation');
    }
  };
  
  // Handle any errors
  xhr.onerror = function() {
    console.error('Error loading navigation');
  };
  
  // Send the request
  xhr.send();
}

// Function to update the active navigation item based on current page
function updateActiveNavItem() {
  // Get the current page filename
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  
  // Remove active class from all nav links
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.remove('active');
    link.setAttribute('aria-current', null);
  });
  
  // Find and activate the current page's nav item
  let activeLink = null;
  
  if (currentPage === 'index.html' || currentPage === '') {
    activeLink = document.querySelector('.nav-link[href="index.html"]');
  } else {
    activeLink = document.querySelector(`.nav-link[href="${currentPage}"]`);
  }
  
  if (activeLink) {
    activeLink.classList.add('active');
    activeLink.setAttribute('aria-current', 'page');
  }
}

// Load the navigation when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', loadNavigation);
